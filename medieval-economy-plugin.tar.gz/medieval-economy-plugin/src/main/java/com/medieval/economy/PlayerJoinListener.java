package com.medieval.economy;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerJoinListener implements Listener {
    
    @Override
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        MedievalEconomy plugin = MedievalEconomy.getInstance();
        
        if (!player.hasPlayedBefore()) {
            int starterCoins = plugin.getConfig().getInt("starter-coins", 100);
            plugin.setBalance(player.getUniqueId(), starterCoins);
            String msg = plugin.getConfig().getString("messages.received-starter", "§aWelcome! You received §6100 starter coins§a!");
            player.sendMessage(plugin.getConfig().getString("messages.prefix", "§6[Medieval] §r") + msg.replace("§aWelcome! You received §6100 starter coins§a!", "§aWelcome! You received §6" + starterCoins + " starter coins§a!"));
            player.sendMessage("§6§l=== Medieval Kingdom SMP ===§r");
            player.sendMessage("§eUse §a/shop §eto open the shop | §a/balance §eto check coins | §a/pay <player> <amount>");
        }
    }
}
