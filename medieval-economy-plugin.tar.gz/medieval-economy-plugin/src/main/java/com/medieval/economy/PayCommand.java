package com.medieval.economy;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PayCommand implements CommandExecutor {
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }
        
        Player player = (Player) sender;
        MedievalEconomy plugin = MedievalEconomy.getInstance();
        String prefix = plugin.getConfig().getString("messages.prefix", "§6[Medieval] §r");
        
        if (args.length < 2) {
            player.sendMessage(prefix + "§cUsage: /pay <player> <amount>");
            return true;
        }
        
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(prefix + plugin.getConfig().getString("messages.player-not-found", "§cPlayer not found!"));
            return true;
        }
        
        if (target.equals(player)) {
            player.sendMessage(prefix + plugin.getConfig().getString("messages.cannot-pay-self", "§cYou cannot pay yourself!"));
            return true;
        }
        
        double amount;
        try {
            amount = Double.parseDouble(args[1]);
            if (amount <= 0) {
                player.sendMessage(prefix + plugin.getConfig().getString("messages.invalid-amount", "§cInvalid amount!"));
                return true;
            }
        } catch (NumberFormatException e) {
            player.sendMessage(prefix + plugin.getConfig().getString("messages.invalid-amount", "§cInvalid amount!"));
            return true;
        }
        
        if (!plugin.hasBalance(player.getUniqueId(), amount)) {
            player.sendMessage(prefix + plugin.getConfig().getString("messages.insufficient-funds", "§cYou don't have enough coins!"));
            return true;
        }
        
        plugin.removeBalance(player.getUniqueId(), amount);
        plugin.addBalance(target.getUniqueId(), amount);
        
        player.sendMessage(prefix + "§aYou sent §6" + String.format("%.0f", amount) + " coins§a to §e" + target.getName());
        target.sendMessage(prefix + "§aYou received §6" + String.format("%.0f", amount) + " coins§a from §e" + player.getName());
        
        return true;
    }
}
