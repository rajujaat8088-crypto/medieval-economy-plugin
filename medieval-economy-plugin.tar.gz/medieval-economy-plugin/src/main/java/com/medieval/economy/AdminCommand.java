package com.medieval.economy;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class AdminCommand implements CommandExecutor {
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        MedievalEconomy plugin = MedievalEconomy.getInstance();
        String prefix = plugin.getConfig().getString("messages.prefix", "§6[Medieval] §r");
        
        if (!sender.hasPermission("medievaleconomy.admin")) {
            sender.sendMessage(prefix + "§cYou don't have permission!");
            return true;
        }
        
        if (args.length == 0) {
            sender.sendMessage(prefix + "§eMedievalEconomy v1.0.0");
            sender.sendMessage("§7/medievaleconomy reload - Reload config");
            return true;
        }
        
        if (args[0].equalsIgnoreCase("reload")) {
            plugin.reloadConfig();
            sender.sendMessage(prefix + "§aConfig reloaded!");
            return true;
        }
        
        return true;
    }
}
