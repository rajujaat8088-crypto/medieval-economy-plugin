package com.medieval.economy;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BalanceCommand implements CommandExecutor {
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }
        
        Player player = (Player) sender;
        MedievalEconomy plugin = MedievalEconomy.getInstance();
        double balance = plugin.getBalance(player.getUniqueId());
        
        String prefix = plugin.getConfig().getString("messages.prefix", "§6[Medieval] §r");
        player.sendMessage(prefix + "§eYour balance: §6" + String.format("%.0f", balance) + " coins");
        
        return true;
    }
}
