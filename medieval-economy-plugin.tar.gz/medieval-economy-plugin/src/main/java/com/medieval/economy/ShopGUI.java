package com.medieval.economy;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ShopGUI implements Listener {
    
    private static MedievalEconomy plugin = MedievalEconomy.getInstance();
    
    public static void openMainMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, "§6§lMedieval Shops");
        
        // Food
        inv.setItem(10, createItem(Material.BREAD, "§6§lFarming Shop", "§7Buy & Sell food items", "§eClick to open!"));
        // Tools
        inv.setItem(11, createItem(Material.IRON_PICKAXE, "§6§lBlacksmith Shop", "§7Buy & Sell tools", "§eClick to open!"));
        // Armor
        inv.setItem(12, createItem(Material.IRON_CHESTPLATE, "§6§lArmory", "§7Buy & Sell armor", "§eClick to open!"));
        // Blocks
        inv.setItem(13, createItem(Material.BRICKS, "§6§lBuilding Shop", "§7Buy & Sell blocks", "§eClick to open!"));
        // Ores
        inv.setItem(14, createItem(Material.DIAMOND, "§6§lMining Shop", "§7Buy & Sell ores", "§eClick to open!"));
        // Farming
        inv.setItem(15, createItem(Material.WHEAT_SEEDS, "§6§lFarming Supplies", "§7Seeds & farming items", "§eClick to open!"));
        // Sell
        inv.setItem(16, createItem(Material.GOLD_INGOT, "§e§lSell Items", "§7Sell items from your inventory", "§eClick to open!"));
        // Balance
        inv.setItem(22, createItem(Material.EMERALD, "§a§lYour Balance", "§e" + String.format("%.0f", plugin.getBalance(player.getUniqueId())) + " Coins", "§7Use /pay to send coins"));
        
        player.openInventory(inv);
    }
    
    private static ItemStack createItem(Material mat, String name, String... lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        List<String> loreList = new ArrayList<>();
        for (String l : lore) {
            loreList.add(l);
        }
        meta.setLore(loreList);
        item.setItemMeta(meta);
        return item;
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        String title = event.getView().getTitle();
        
        if (title.equals("§6§lMedieval Shops")) {
            event.setCancelled(true);
            if (event.getCurrentItem() == null) return;
            
            int slot = event.getRawSlot();
            if (slot == 10) openCategory(player, "food");
            else if (slot == 11) openCategory(player, "tools");
            else if (slot == 12) openCategory(player, "armor");
            else if (slot == 13) openCategory(player, "blocks");
            else if (slot == 14) openCategory(player, "ores");
            else if (slot == 15) openCategory(player, "farming");
            else if (slot == 16) openSellMenu(player);
            else if (slot == 22) {
                player.closeInventory();
                player.sendMessage(plugin.getConfig().getString("messages.prefix", "§6[Medieval] §r") + 
                    "§eYour balance: §6" + String.format("%.0f", plugin.getBalance(player.getUniqueId())) + " coins");
            }
        } else if (title.contains("Shop")) {
            event.setCancelled(true);
            handleShopClick(player, event, title);
        } else if (title.equals("§e§lSell Items")) {
            event.setCancelled(true);
            handleSellClick(player, event);
        }
    }
    
    private void openCategory(Player player, String category) {
        String shopTitle = plugin.getConfig().getString("shops." + category + ".title", "§6§lShop");
        Inventory inv = Bukkit.createInventory(null, 54, shopTitle);
        
        // Add items from config
        if (plugin.getConfig().contains("shops." + category + ".items")) {
            for (String key : plugin.getConfig().getConfigurationSection("shops." + category + ".items").getKeys(false)) {
                String path = "shops." + category + ".items." + key;
                Material mat = Material.valueOf(plugin.getConfig().getString(path + ".material"));
                int buy = plugin.getConfig().getInt(path + ".price-buy");
                int sell = plugin.getConfig().getInt(path + ".price-sell");
                int amount = plugin.getConfig().getInt(path + ".amount", 1);
                
                ItemStack item = new ItemStack(mat, amount);
                ItemMeta meta = item.getItemMeta();
                meta.setDisplayName("§e" + formatName(mat.name()));
                List<String> lore = new ArrayList<>();
                lore.add("§7Buy: §a" + buy + " coins");
                if (sell > 0) lore.add("§7Sell: §6" + sell + " coins");
                lore.add("");
                lore.add("§eLeft Click: §aBuy");
                lore.add("§eRight Click: §6Sell");
                meta.setLore(lore);
                item.setItemMeta(meta);
                inv.addItem(item);
            }
        }
        
        // Back button
        inv.setItem(49, createItem(Material.ARROW, "§c§lBack to Main Menu", "§7Return to shop selection"));
        player.openInventory(inv);
    }
    
    private void handleShopClick(Player player, InventoryClickEvent event, String title) {
        if (event.getCurrentItem() == null) return;
        if (event.getRawSlot() == 49) {
            openMainMenu(player);
            return;
        }
        
        ItemStack item = event.getCurrentItem();
        Material mat = item.getType();
        String itemName = formatName(mat.name());
        
        // Find price
        int buyPrice = 0, sellPrice = 0;
        String category = getCategoryFromTitle(title);
        if (category != null && plugin.getConfig().contains("shops." + category + ".items")) {
            for (String key : plugin.getConfig().getConfigurationSection("shops." + category + ".items").getKeys(false)) {
                String path = "shops." + category + ".items." + key;
                if (plugin.getConfig().getString(path + ".material").equals(mat.name())) {
                    buyPrice = plugin.getConfig().getInt(path + ".price-buy");
                    sellPrice = plugin.getConfig().getInt(path + ".price-sell");
                    break;
                }
            }
        }
        
        if (event.isLeftClick()) {
            // Buy
            if (buyPrice == 0) {
                player.sendMessage(plugin.getConfig().getString("messages.prefix", "§6[Medieval] §r") + "§cThis item cannot be bought!");
                return;
            }
            if (!plugin.hasBalance(player.getUniqueId(), buyPrice)) {
                player.sendMessage(plugin.getConfig().getString("messages.prefix", "§6[Medieval] §r") + 
                    plugin.getConfig().getString("messages.insufficient-funds", "§cYou don't have enough coins!"));
                return;
            }
            plugin.removeBalance(player.getUniqueId(), buyPrice);
            player.getInventory().addItem(new ItemStack(mat, item.getAmount()));
            player.sendMessage(plugin.getConfig().getString("messages.prefix", "§6[Medieval] §r") + 
                "§aPurchased §e" + itemName + "§a for §6" + buyPrice + " coins");
        } else if (event.isRightClick()) {
            // Sell
            if (sellPrice == 0) {
                player.sendMessage(plugin.getConfig().getString("messages.prefix", "§6[Medieval] §r") + "§cThis item cannot be sold!");
                return;
            }
            // Count items in inventory
            int count = 0;
            for (ItemStack invItem : player.getInventory().getContents()) {
                if (invItem != null && invItem.getType() == mat) {
                    count += invItem.getAmount();
                }
            }
            if (count == 0) {
                player.sendMessage(plugin.getConfig().getString("messages.prefix", "§6[Medieval] §r") + "§cYou don't have this item!");
                return;
            }
            // Remove one stack worth or all? Remove what player has
            ItemStack toRemove = new ItemStack(mat, Math.min(item.getAmount(), count));
            player.getInventory().removeItem(toRemove);
            int total = sellPrice * toRemove.getAmount();
            plugin.addBalance(player.getUniqueId(), total);
            player.sendMessage(plugin.getConfig().getString("messages.prefix", "§6[Medieval] §r") + 
                "§aSold §e" + itemName + " x" + toRemove.getAmount() + "§a for §6" + total + " coins");
        }
    }
    
    private void openSellMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, "§e§lSell Items");
        // Show sellable items in inventory
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() != Material.AIR) {
                int sellPrice = getSellPrice(item.getType());
                if (sellPrice > 0) {
                    ItemStack display = item.clone();
                    ItemMeta meta = display.getItemMeta();
                    List<String> lore = new ArrayList<>();
                    if (meta.hasLore()) lore.addAll(meta.getLore());
                    lore.add("");
                    lore.add("§7Sell: §6" + (sellPrice * item.getAmount()) + " coins");
                    lore.add("§eClick to sell all");
                    meta.setLore(lore);
                    display.setItemMeta(meta);
                    inv.addItem(display);
                }
            }
        }
        inv.setItem(49, createItem(Material.ARROW, "§c§lBack to Main Menu", "§7Return to shop selection"));
        player.openInventory(inv);
    }
    
    private void handleSellClick(Player player, InventoryClickEvent event) {
        if (event.getCurrentItem() == null) return;
        if (event.getRawSlot() == 49) {
            openMainMenu(player);
            return;
        }
        ItemStack item = event.getCurrentItem();
        if (item.getType() == Material.AIR) return;
        int sellPrice = getSellPrice(item.getType());
        if (sellPrice == 0) {
            player.sendMessage(plugin.getConfig().getString("messages.prefix", "§6[Medieval] §r") + "§cThis item cannot be sold!");
            return;
        }
        // Count all
        int count = 0;
        for (ItemStack invItem : player.getInventory().getContents()) {
            if (invItem != null && invItem.getType() == item.getType()) {
                count += invItem.getAmount();
            }
        }
        player.getInventory().removeItem(new ItemStack(item.getType(), count));
        int total = sellPrice * count;
        plugin.addBalance(player.getUniqueId(), total);
        player.sendMessage(plugin.getConfig().getString("messages.prefix", "§6[Medieval] §r") + 
            "§aSold §e" + formatName(item.getType().name()) + " x" + count + "§a for §6" + total + " coins");
        openSellMenu(player);
    }
    
    private int getSellPrice(Material mat) {
        for (String cat : new String[]{"food", "tools", "armor", "blocks", "ores", "farming"}) {
            if (plugin.getConfig().contains("shops." + cat + ".items")) {
                for (String key : plugin.getConfig().getConfigurationSection("shops." + cat + ".items").getKeys(false)) {
                    String path = "shops." + cat + ".items." + key;
                    if (plugin.getConfig().getString(path + ".material").equals(mat.name())) {
                        return plugin.getConfig().getInt(path + ".price-sell");
                    }
                }
            }
        }
        return 0;
    }
    
    private String getCategoryFromTitle(String title) {
        if (title.contains("Farming Shop") && !title.contains("Supplies")) return "food";
        if (title.contains("Blacksmith")) return "tools";
        if (title.contains("Armory")) return "armor";
        if (title.contains("Building")) return "blocks";
        if (title.contains("Mining Shop")) return "ores";
        if (title.contains("Farming Supplies")) return "farming";
        return null;
    }
    
    private static String formatName(String name) {
        String[] parts = name.split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!part.isEmpty()) {
                sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1).toLowerCase()).append(" ");
            }
        }
        return sb.toString().trim();
    }
}
