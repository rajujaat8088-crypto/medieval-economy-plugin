package com.medieval.economy;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.UUID;

public class MedievalEconomy extends JavaPlugin {
    
    private static MedievalEconomy instance;
    private HashMap<UUID, Double> balances = new HashMap<>();
    private Connection connection;
    private String databaseType = "sqlite";
    
    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        
        setupDatabase();
        loadAllBalances();
        
        // Register commands
        getCommand("balance").setExecutor(new BalanceCommand());
        getCommand("pay").setExecutor(new PayCommand());
        getCommand("shop").setExecutor(new ShopCommand());
        getCommand("medievaleconomy").setExecutor(new AdminCommand());
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new PlayerJoinListener(), this);
        
        getLogger().info("MedievalEconomy has been enabled!");
        getLogger().info("Coins economy system loaded successfully!");
    }
    
    @Override
    public void onDisable() {
        saveAllBalances();
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        getLogger().info("MedievalEconomy has been disabled!");
    }
    
    public static MedievalEconomy getInstance() {
        return instance;
    }
    
    private void setupDatabase() {
        File dbFile = new File(getDataFolder(), "economy.db");
        if (!getDataFolder().exists()) {
            getDataFolder().mkdirs();
        }
        
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
            PreparedStatement ps = connection.prepareStatement(
                "CREATE TABLE IF NOT EXISTS economy (" +
                "uuid VARCHAR(36) PRIMARY KEY, " +
                "balance DOUBLE DEFAULT 0" +
                ")"
            );
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
            getLogger().severe("Failed to setup database!");
        }
    }
    
    public void loadAllBalances() {
        try {
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM economy");
            var rs = ps.executeQuery();
            while (rs.next()) {
                UUID uuid = UUID.fromString(rs.getString("uuid"));
                double balance = rs.getDouble("balance");
                balances.put(uuid, balance);
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void saveAllBalances() {
        try {
            for (UUID uuid : balances.keySet()) {
                PreparedStatement ps = connection.prepareStatement(
                    "INSERT OR REPLACE INTO economy (uuid, balance) VALUES (?, ?)"
                );
                ps.setString(1, uuid.toString());
                ps.setDouble(2, balances.get(uuid));
                ps.executeUpdate();
                ps.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void saveBalance(UUID uuid) {
        try {
            PreparedStatement ps = connection.prepareStatement(
                "INSERT OR REPLACE INTO economy (uuid, balance) VALUES (?, ?)"
            );
            ps.setString(1, uuid.toString());
            ps.setDouble(2, getBalance(uuid));
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public double getBalance(UUID uuid) {
        return balances.getOrDefault(uuid, 0.0);
    }
    
    public void setBalance(UUID uuid, double amount) {
        balances.put(uuid, Math.max(0, amount));
        saveBalance(uuid);
    }
    
    public void addBalance(UUID uuid, double amount) {
        setBalance(uuid, getBalance(uuid) + amount);
    }
    
    public void removeBalance(UUID uuid, double amount) {
        setBalance(uuid, getBalance(uuid) - amount);
    }
    
    public boolean hasBalance(UUID uuid, double amount) {
        return getBalance(uuid) >= amount;
    }
}
